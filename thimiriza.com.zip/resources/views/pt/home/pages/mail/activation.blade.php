<h1>BEM-VINDO AO THIMIRIZA</h1>
<p>Registou com sucesso a empresa {{ $name }}</p>
<p>Por favor clique no link abaixo para activar a tua conta</p>
<p><a href="{{$name}}">Activar conta</a></p>