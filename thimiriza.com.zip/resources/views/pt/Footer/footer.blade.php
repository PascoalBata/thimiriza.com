<div class="footer-copyright">
    <div class="container black-text center-align">
        Copyright ©{{date('Y', strtotime(now()))}} Thimiriza
        <br/>
        <a class="black-text" href="#!">Termos & Condições</a>
    </div>
</div>
